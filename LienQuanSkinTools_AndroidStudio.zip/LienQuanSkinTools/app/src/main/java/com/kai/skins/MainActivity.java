package com.kai.skins;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.*;

public class MainActivity extends Activity {
    private final String[][] skins = {
        {"Nakroth", "Siêu Việt", "S+"},
        {"Murad", "Chí Tôn", "S+"},
        {"Airi", "Thứ Nguyên Vệ Thần", "S"},
        {"Violet", "Thứ Nguyên Vệ Thần", "S"},
        {"Florentino", "Tinh Hệ", "S"},
        {"Tel'Annas", "Thần Sứ F.E.E-X1", "SS"},
        {"Yena", "Huyền Cửu Thiên", "SS"},
        {"Hayate", "Bạch Ảnh", "S"},
        {"Liliana", "Thần Tượng Âm Nhạc", "S"}
    };
    private LinearLayout list;
    private EditText search;
    private boolean favoritesOnly = false;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("skin_favorites", MODE_PRIVATE);
        buildUi();
        render("");
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(20, 28, 20, 16);
        page.setBackgroundColor(Color.rgb(14, 15, 22));

        TextView title = text("LIÊN QUÂN", 27, Color.WHITE, true);
        page.addView(title);
        TextView subtitle = text("SKIN TOOLS  •  BỘ SƯU TẬP", 12, Color.rgb(255, 190, 65), true);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 4;
        page.addView(subtitle, sp);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Tìm theo tên tướng hoặc skin...");
        search.setHintTextColor(Color.LTGRAY);
        search.setTextColor(Color.WHITE);
        search.setPadding(16, 10, 16, 10);
        search.setBackground(bg(Color.rgb(34, 36, 48), 18));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = 20;
        page.addView(search, ep);

        Button all = new Button(this);
        all.setText("TẤT CẢ SKIN");
        Button fav = new Button(this);
        fav.setText("♥ YÊU THÍCH");
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.addView(all, new LinearLayout.LayoutParams(0, -2, 1));
        tabs.addView(fav, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);

        all.setOnClickListener(v -> { favoritesOnly = false; render(search.getText().toString()); });
        fav.setOnClickListener(v -> { favoritesOnly = true; render(search.getText().toString()); });
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { render(s.toString()); }
            public void afterTextChanged(Editable e) {}
        });
    }

    private void render(String query) {
        if (list == null) return;
        list.removeAllViews();
        String q = query.toLowerCase(Locale.ROOT).trim();
        int count = 0;
        for (String[] item : skins) {
            if (item.length < 3) continue;
            String hero = item[0], skin = item[1], rarity = item[2];
            boolean match = (hero + " " + skin + " " + rarity).toLowerCase(Locale.ROOT).contains(q);
            boolean favorite = prefs.getBoolean(hero + "|" + skin, false);
            if (!match || (favoritesOnly && !favorite)) continue;

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(16, 14, 16, 14);
            card.setBackground(bg(Color.rgb(30, 32, 43), 16));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.topMargin = 10;
            list.addView(card, cp);

            TextView heroText = text(hero, 17, Color.WHITE, true);
            card.addView(heroText);
            TextView skinText = text(skin, 14, Color.rgb(220, 220, 230), false);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
            tp.topMargin = 4;
            card.addView(skinText, tp);

            LinearLayout bottom = new LinearLayout(this);
            bottom.setGravity(Gravity.CENTER_VERTICAL);
            bottom.setOrientation(LinearLayout.HORIZONTAL);
            TextView tier = text("ĐỘ HIẾM: " + rarity, 12, Color.rgb(255, 190, 65), true);
            bottom.addView(tier, new LinearLayout.LayoutParams(0, -2, 1));
            Button heart = new Button(this);
            heart.setText(favorite ? "♥ Đã lưu" : "♡ Yêu thích");
            heart.setOnClickListener(v -> {
                prefs.edit().putBoolean(hero + "|" + skin, !favorite).apply();
                render(search.getText().toString());
            });
            bottom.addView(heart);
            card.addView(bottom);
            count++;
        }
        if (count == 0) {
            TextView empty = text("Không tìm thấy skin phù hợp.", 14, Color.LTGRAY, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(8, 28, 8, 28);
            list.addView(empty);
        }
    }
}
