# Liên Quân Skin Tools

Ứng dụng Android quản lý danh sách skin: tìm kiếm, lọc danh sách yêu thích và lưu yêu thích trên thiết bị.

## Build APK bằng Android Studio
1. Cài Android Studio phiên bản mới và Android SDK Platform 35.
2. Chọn **Open** và mở thư mục `LienQuanSkinTools`.
3. Chờ Gradle Sync hoàn tất (JDK 17, Gradle 8.9).
4. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK được tạo trong `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK tự động trên GitHub
1. Tạo repository GitHub và tải toàn bộ nội dung thư mục này lên.
2. Mở tab **Actions**.
3. Chọn workflow **Build Android APK** rồi nhấn **Run workflow** (hoặc push lên nhánh `main`).
4. Khi chạy xong, mở lần chạy workflow và tải artifact `LienQuanSkinTools-debug-apk`.

Ứng dụng chỉ quản lý bộ sưu tập hiển thị trong app; không can thiệp Liên Quân, không mở khóa skin trên máy chủ và không thay đổi tài khoản/game.
